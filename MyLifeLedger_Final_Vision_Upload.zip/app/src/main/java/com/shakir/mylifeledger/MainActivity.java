package com.shakir.mylifeledger;

import android.app.Activity;
import android.content.Intent;
import android.content.Context;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.database.Cursor;
import android.provider.ContactsContract;
import android.app.AlarmManager;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.os.Build;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.SystemClock;
import android.graphics.Color;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.graphics.Insets;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.app.NotificationCompat;
import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.fragment.app.FragmentActivity;
import java.util.concurrent.Executor;

public class MainActivity extends FragmentActivity {
    private WebView webView;
    private ValueCallback<Uri[]> fileCallback;
    private static final int FILE_CHOOSER_REQUEST = 2048;
    private static final int CONTACT_PICKER_REQUEST = 2049;
    private static final int NOTIFICATION_PERMISSION_REQUEST = 2050;
    private String pendingReminderTitle = "";
    private String pendingReminderMessage = "";
    private long pendingReminderTime = 0L;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        createNotificationChannel();
        webView = new WebView(this);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        ViewCompat.setOnApplyWindowInsetsListener(webView, (view, windowInsets) -> {
            Insets bars = windowInsets.getInsets(WindowInsetsCompat.Type.systemBars());
            view.setPadding(0, bars.top, 0, 0);
            return windowInsets;
        });
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setSupportZoom(false);
        settings.setBuiltInZoomControls(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                try { startActivityForResult(intent, FILE_CHOOSER_REQUEST); }
                catch (Exception e) { fileCallback = null; callback.onReceiveValue(null); return false; }
                return true;
            }
        });
        webView.addJavascriptInterface(new AndroidAuth(), "AndroidAuth");
        webView.addJavascriptInterface(new AndroidContacts(), "AndroidContacts");
        webView.addJavascriptInterface(new AndroidNotify(), "AndroidNotify");
        setContentView(webView);
        if (savedInstanceState == null) webView.loadUrl("file:///android_asset/index.html");
        else webView.restoreState(savedInstanceState);
    }

    private class AndroidAuth {
        @JavascriptInterface public void authenticate() {
            runOnUiThread(() -> {
                BiometricManager manager = BiometricManager.from(MainActivity.this);
                int can = manager.canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK);
                if (can != BiometricManager.BIOMETRIC_SUCCESS) {
                    webView.evaluateJavascript("onBiometricResult(false)", null);
                    return;
                }
                Executor executor = ContextCompat.getMainExecutor(MainActivity.this);
                BiometricPrompt prompt = new BiometricPrompt(MainActivity.this, executor, new BiometricPrompt.AuthenticationCallback() {
                    @Override public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                        webView.evaluateJavascript("onBiometricResult(true)", null);
                    }
                    @Override public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                        webView.evaluateJavascript("onBiometricResult(false)", null);
                    }
                    @Override public void onAuthenticationFailed() { /* Keep the biometric prompt open for another attempt. */ }
                });
                BiometricPrompt.PromptInfo info = new BiometricPrompt.PromptInfo.Builder()
                    .setTitle("MyLife Ledger Settings")
                    .setSubtitle("Verify your identity")
                    .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG | BiometricManager.Authenticators.BIOMETRIC_WEAK)
                    .setNegativeButtonText("Cancel")
                    .build();
                prompt.authenticate(info);
            });
        }
    }

    private class AndroidContacts {
        @JavascriptInterface public void pickContact() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                    startActivityForResult(intent, CONTACT_PICKER_REQUEST);
                } catch (Exception e) {
                    webView.evaluateJavascript("onContactPicked('', '')", null);
                }
            });
        }
    }

    private class AndroidNotify {
        @JavascriptInterface public void scheduleReminder(String title, String message, long timeMillis) {
            runOnUiThread(() -> {
                pendingReminderTitle = title == null ? "MyLife Ledger reminder" : title;
                pendingReminderMessage = message == null ? "You have a reminder." : message;
                pendingReminderTime = timeMillis;
                if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(MainActivity.this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                    ActivityCompat.requestPermissions(MainActivity.this, new String[]{Manifest.permission.POST_NOTIFICATIONS}, NOTIFICATION_PERMISSION_REQUEST);
                } else {
                    scheduleReminderNow(pendingReminderTitle, pendingReminderMessage, pendingReminderTime);
                }
            });
        }
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel("mylife_reminders", "MyLife Ledger reminders", NotificationManager.IMPORTANCE_HIGH);
            channel.setDescription("Personal reminders from MyLife Ledger");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);
        }
    }

    private void scheduleReminderNow(String title, String message, long timeMillis) {
        if (timeMillis <= System.currentTimeMillis()) {
            webView.evaluateJavascript("onReminderScheduled(false)", null);
            return;
        }
        int id = (title + timeMillis).hashCode() & 0x7fffffff;
        Intent intent = new Intent(this, ReminderReceiver.class);
        intent.putExtra("title", title);
        intent.putExtra("message", message);
        PendingIntent pending = PendingIntent.getBroadcast(this, id, intent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        AlarmManager alarm = (AlarmManager) getSystemService(ALARM_SERVICE);
        if (alarm != null) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, timeMillis, pending);
            else alarm.set(AlarmManager.RTC_WAKEUP, timeMillis, pending);
            webView.evaluateJavascript("onReminderScheduled(true)", null);
        } else webView.evaluateJavascript("onReminderScheduled(false)", null);
    }

    public static class ReminderReceiver extends BroadcastReceiver {
        @Override public void onReceive(Context context, Intent intent) {
            String title = intent.getStringExtra("title");
            String message = intent.getStringExtra("message");
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                NotificationChannel channel = new NotificationChannel("mylife_reminders", "MyLife Ledger reminders", NotificationManager.IMPORTANCE_HIGH);
                NotificationManager nm = context.getSystemService(NotificationManager.class);
                if (nm != null) nm.createNotificationChannel(channel);
            }
            Intent open = context.getPackageManager().getLaunchIntentForPackage(context.getPackageName());
            PendingIntent content = PendingIntent.getActivity(context, (title == null ? 0 : title.hashCode()) & 0x7fffffff, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
            NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "mylife_reminders")
                .setSmallIcon(com.shakir.mylifeledger.R.drawable.ic_mylife_ledger)
                .setContentTitle(title == null ? "MyLife Ledger" : title)
                .setContentText(message == null ? "Reminder" : message)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(message == null ? "Reminder" : message))
                .setPriority(NotificationCompat.PRIORITY_HIGH).setAutoCancel(true).setContentIntent(content);
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm != null && (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED)) {
                nm.notify((title == null ? 0 : title.hashCode()) & 0x7fffffff, builder.build());
            }
        }
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER_REQUEST && fileCallback != null) {
            Uri[] result = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            fileCallback.onReceiveValue(result);
            fileCallback = null;
        } else if (requestCode == CONTACT_PICKER_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            String name = "", number = "";
            Cursor cursor = null;
            try {
                cursor = getContentResolver().query(data.getData(), new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER}, null, null, null);
                if (cursor != null && cursor.moveToFirst()) {
                    name = cursor.getString(0) == null ? "" : cursor.getString(0);
                    number = cursor.getString(1) == null ? "" : cursor.getString(1);
                }
            } catch (Exception ignored) { }
            finally { if (cursor != null) cursor.close(); }
            webView.evaluateJavascript("onContactPicked(" + org.json.JSONObject.quote(name) + "," + org.json.JSONObject.quote(number) + ")", null);
        }
    }
    @Override public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == NOTIFICATION_PERMISSION_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                scheduleReminderNow(pendingReminderTitle, pendingReminderMessage, pendingReminderTime);
            } else if (webView != null) {
                webView.evaluateJavascript("onReminderScheduled(false)", null);
            }
        }
    }

    @Override protected void onSaveInstanceState(Bundle outState) { webView.saveState(outState); super.onSaveInstanceState(outState); }
    @Override public void onBackPressed() { if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed(); }
}
