MyLife Ledger — Updated Android source (v1.1)

Is ZIP mein Android WebView app ka source code hai; yeh khud compiled APK nahi hai. GitHub Actions workflow se APK build hoti hai.

Is update mein:
- Settings par PIN 1993 prompt; PIN galat ho to supported Android fingerprint/biometric prompt try kiya ja sakta hai.
- Android WebView file picker support add ki gayi hai taake Settings se logo image select ho sake.
- App launcher ke liye custom MyLife Ledger vector icon add kiya gaya hai.
- Home screen header spacing aur footer ko compact kiya gaya; footer par sirf Powered by naam/number hai.
- PDF/print reports ke liye print margins, centered app branding/report title, table borders aur page-break styling add ki gayi.
- Android auto-backup disable kiya gaya hai, taake personal data unintended Android backup mein na jaye.

Build:
1. ZIP extract karke project ki files GitHub repository ke root mein upload/replace karein.
2. Commit karein; GitHub Actions mein Build MyLife Ledger APK workflow khulega.
3. Successful run ke Artifacts section se MyLife-Ledger-APK download karein aur phone par extract karein.

Security note:
PIN gate app ke Settings UI ko protect karta hai, lekin source-code access rakhne wala shakhs ise bypass kar sakta hai. Is build ko high-security vault na samjhein. Android fingerprint is build mein Settings gate ke alternate ke taur par integrated hai; device par fingerprint/biometric enrollment aur Android support zaroori hai. Data abhi WebView localStorage mein hai, encryption-at-rest abhi implement nahi hai. APK ko phone par test karein; yahan Android build execute karke verify nahi kiya gaya.
